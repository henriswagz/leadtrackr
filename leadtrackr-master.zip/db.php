<?php
$mysql_db = "adsstud1_app";
$mysql_user = "adsstud1_app";
$mysql_pass = "masterclas303!!!";
$mysql_link = mysql_connect("localhost", $mysql_user, $mysql_pass);
mysql_select_db($mysql_db, $mysql_link);
?>
