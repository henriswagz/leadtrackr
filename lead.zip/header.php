<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>LeadTracker: Welcome </title>
	<link rel="stylesheet" href="jquery.mobile-1.4.5.min.css" />
	<script src="jquery-1.7.min.js"></script>
	<script src="jquery.mobile-1.4.5.min.js"></script>
	<link rel="stylesheet" href="themes/second.min.css" />
	<link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
	

	<!--<head>
	<title>Lead Tracker App</title>
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0a3/jquery.mobile-1.0a3.min.css" />
	<script src="http://code.jquery.com/jquery-1.5.min.js"></script>
	
	<script src="http://code.jquery.com/mobile/1.0a3/jquery.mobile-1.0a3.min.js"></script>
	<script src="http://jquery.ibm.navitend.com/utils.js"></script>
	-->
</head>
